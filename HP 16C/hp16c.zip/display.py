import tkinter as tk
import stack

class Display:
    def __init__(self, master, x, y, width, height, font=None):
        self.master = master
        self.current_entry = ""
        self.font = font if font is not None else ("Courier", 18)

        self.frame = tk.Frame(master, bg="#9C9C9C")
        self.frame.place(x=x, y=y, width=width, height=height)

        self.widget = tk.Text(self.frame, bg="#9C9C9C", font=self.font)
        self.widget.place(x=0, y=0, width=width, height=height)

        self.mode_label = tk.Label(self.frame, font=("Courier", 10), bg="#9C9C9C")
        self.mode_label.place(x=2, rely=1.0, anchor="sw")

        self.stack_label = tk.Label(self.frame, font=("Courier", 8), bg="#9C9C9C")
        self.stack_label.place(relx=1.0, rely=1.0, anchor="se")

        self.current_entry = ""

    def append_entry(self, ch):
        self.current_entry += ch
        self.update()

    def set_entry(self, entry):
        self.current_entry = entry
        self.update()

    def get_entry(self):
        return self.current_entry

    def clear_entry(self):
        self.current_entry = ""
        self.update()

    def update(self):
        self.widget.delete("1.0", "end")
        self.widget.insert("1.0", self.current_entry)

    def set_mode(self, mode_str):  # <--- Add this method
        self.mode_label.config(text=mode_str)

    def show_error(self, title, message):
        print(f"{title}: {message}")
