# f_key.py
from toggle_helpers import revert_to_normal
from f_function import f_action

# Global flag to track whether f-mode is active.
f_mode_active = False

def toggle_f_state(button_widgets):
    global f_mode_active
    # If f-mode is already active, cancel it by reverting all non-toggle buttons.
    if f_mode_active:
        for btn in button_widgets:
            # Skip the f toggle button so its yellow color remains.
            if btn.get("command_name") == "yellow_f_function":
                continue
            # Also skip the g toggle button.
            if btn.get("command_name") == "blue_g_function":
                continue
            revert_to_normal(btn)
        f_mode_active = False
        return

    # Activate f-mode.
    f_mode_active = True
    for btn in button_widgets:
        # Skip both toggle buttons so their colors remain unchanged.
        if btn.get("command_name") in ("yellow_f_function", "blue_g_function"):
            continue

        # For non-toggle buttons, first revert then apply f-mode styling.
        revert_to_normal(btn)
        frame = btn["frame"]
        top_label = btn.get("top_label_widget")
        if top_label:
            frame.config(bg="#e3af01")
            top_label.config(bg="#e3af01", fg="black")
            top_label.place(relx=0.5, rely=0.5, anchor="center")
            # Hide the other labels.
            if btn.get("main_label_widget"):
                btn.get("main_label_widget").place_forget()
            if btn.get("sub_label_widget"):
                btn.get("sub_label_widget").place_forget()
            # Bind click events for f-action.
            bind_widgets_to_f_action(btn, button_widgets)

def bind_widgets_to_f_action(btn, button_widgets):
    widgets = [
        btn["frame"],
        btn.get("top_label_widget"),
        btn.get("main_label_widget"),
        btn.get("sub_label_widget")
    ]
    for widget in widgets:
        if widget:
            # Freeze the current button reference using a default argument.
            widget.bind("<Button-1>", lambda e, b=btn: execute_f_action(b, button_widgets))

def execute_f_action(button, button_widgets):
    global f_mode_active
    f_action(button)
    # Revert all non-toggle buttons back to normal after executing the f action.
    for btn in button_widgets:
        if btn.get("command_name") in ("yellow_f_function", "blue_g_function"):
            continue
        revert_to_normal(btn)
    f_mode_active = False
