# normal_state_function.py

# Global variable for the display.
display = None

import sys
import os
import subprocess
import stack
from mode_manager import set_mode

def set_display(d):
    """Set the global display reference."""
    global display
    display = d

def normal_action_digit(digit):
    print(f"Normal digit action: {digit}")
    if display:
        display.append_entry(digit)

def normal_action_operator(operator):
    print(f"Normal operator action: {operator}")
    if display:
        try:
            # For an RPN calculator, the top two values on the stack are used.
            # Here, we assume stack.pop() returns the top value.
            operand2 = stack.pop()  # Divisor (the last entered)
            operand1 = stack.pop()  # Dividend (the one below)
            
            if operator == "/":
                result = operand1 / operand2
            elif operator == "*":
                result = operand1 * operand2
            elif operator == "+":
                result = operand1 + operand2
            elif operator == "-":
                result = operand1 - operand2
            else:
                raise ValueError("Unsupported operator")
            
            stack.push(result)
            display.set_entry(str(result))
        except Exception as e:
            display.show_error("Error", str(e))

def normal_action_special(label, buttons, display):
    if label in {"BIN", "OCT", "DEC", "HEX"}:
        set_mode(label, display)  # clearly only two arguments now
    else:
        print(f"Normal action for: {label}")

    if display:  # Ensure display is defined before using it
        if label == "BSP":
            # Backspace: remove last character.
            if display.current_entry:
                new_entry = display.current_entry[:-1]
                display.set_entry(new_entry)

        elif label == "CHS":
            # Change sign example.
            if display.current_entry:
                if display.current_entry.startswith("-"):
                    new_entry = display.current_entry[1:]
                else:
                    new_entry = "-" + display.current_entry
                display.set_entry(new_entry)

        elif label == "ON":
            print(f"HP 16c Restart...")
            # Restart the emulator by launching a new instance of main.pyw
            python = sys.executable  # Get the current Python interpreter path
            subprocess.Popen([python, "main.pyw"])  # Start a new process
            sys.exit(0)  # Exit the current process
            

##############################################################################################################
#                                         Alpha characters actions                                           #
##############################################################################################################

        elif label == "A":
            # Add "a" to the display
            if display.current_entry is None:
                display.set_entry("A")  # If empty, set to "A"
            else:
                display.set_entry(display.current_entry + "A")  # Append "A" to the current entry
        elif label == "B":
            # Add "b" to the display
            if display.current_entry is None:
                display.set_entry("b")  # If empty, set to "b"
            else:
                display.set_entry(display.current_entry + "b")  # Append "A" to the current entry
        elif label == "C":
            # Add "C" to the display
            if display.current_entry is None:
                display.set_entry("C")  # If empty, set to "C"
            else:
                display.set_entry(display.current_entry + "C")  # Append "A" to the current entry
        elif label == "D":
            # Add "d" to the display
            if display.current_entry is None:
                display.set_entry("d")  # If empty, set to "d"
            else:
                display.set_entry(display.current_entry + "d")  # Append "A" to the current entry
        elif label == "E":
            # Add "E" to the display
            if display.current_entry is None:
                display.set_entry("E")  # If empty, set to "E"
            else:
                display.set_entry(display.current_entry + "E")  # Append "A" to the current entry
        elif label == "F":
            # Add "F" to the display
            if display.current_entry is None:
                display.set_entry("F")  # If empty, set to "F"
            else:
                display.set_entry(display.current_entry + "F")  # Append "A" to the current entry

##############################################################################################################

        elif label == "E\nN\nT\nE\nR":
            if display.current_entry:
                try:
                    # Always use float conversion to preserve decimals.
                    value = float(display.current_entry)
                except ValueError:
                    display.show_error("Invalid number", "Conversion failed")
                    return
                stack.push(value)
                print(f"Pushed value: {value}. New stack state: {stack.stack}")
                display.clear_entry()


        # New branch: switching base modes.
        elif label in {"HEX", "OCT", "DEC", "BIN"}:
            # This will change the global base mode and update the display.
            from base_conversion import set_base
            set_base(label, display)

        
        else:
            print(f"No function defined for {label}.")