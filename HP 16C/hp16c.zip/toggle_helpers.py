def revert_to_normal(button):
    """
    Resets the visual state of a button to its original configuration.
    It uses only widget references stored under the *_widget keys.
    """
    # Reset frame background
    frame = button.get("frame")
    if frame:
        frame.config(bg=button.get("orig_bg", "#1e1818"))
    
    # Reset the top label (if present)
    top_widget = button.get("top_label_widget")
    if top_widget:
        top_widget.config(
            fg=button.get("orig_top_fg", "#e3af01"),
            bg=button.get("orig_bg", "#1e1818")
        )
        top_widget.place(relx=0.5, rely=0, anchor="n")
    
    # Reset the main label
    main_widget = button.get("main_label_widget")
    if main_widget:
        # Use the originally stored main text if available; otherwise, use the current text.
        orig_text = button.get("orig_main_text", main_widget.cget("text"))
        main_widget.config(
            text=orig_text,
            fg=button.get("orig_fg", "white"),
            bg=button.get("orig_bg", "#1e1818")
        )
        main_widget.place(relx=0.5, rely=0.5, anchor="center")
    
    # Reset the sub label (if present)
    sub_widget = button.get("sub_label_widget")
    if sub_widget:
        # If you want to restore a stored original sub-text, store it as orig_sub_text.
        # Otherwise, we use the widget's current text.
        orig_sub_text = button.get("orig_sub_text", sub_widget.cget("text"))
        sub_widget.config(
            text=orig_sub_text,
            fg=button.get("orig_sub_fg", "#59b7d1"),
            bg=button.get("orig_bg", "#1e1818")
        )
        sub_widget.place(relx=0.5, rely=1, anchor="s")
