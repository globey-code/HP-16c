import stack
from normal_state_function import display  # reuse existing global display

def f_action(button):
    top_text = button.get("orig_top_text", "")
    print("f action triggered for button with top label:", top_text)
    
    if top_text == "SL":
        action_sl()
    elif top_text == "x><(i)":
        action_x_exchange_i()
    elif top_text == "(i)":
        action_i()
    elif top_text == "SR":
        action_sr()
    else:
        print("No f function defined for top label:", top_text)

# Example meaningful implementations:

def action_sl():
    """Shift the top stack value left by one bit."""
    value = stack.pop()
    result = value << 1
    stack.push(result)
    display.set_entry(str(result))
    print("Shift Left executed:", result)

def action_sr():
    """Shift the top stack value right by one bit."""
    value = stack.pop()
    result = value >> 1
    stack.push(result)
    display.set_entry(str(result))
    print("Shift Right executed:", result)

def action_x_exchange_i():
    """Exchange the contents of X (R0) with a predefined index register (for example R1)."""
    stack.swap()  # assuming swap() swaps R0 and R1
    top_val = stack.peek()
    display.set_entry(str(top_val))
    print("Exchange X with I executed:", top_val)

def action_i():
    """Perform a specific action related to (i). You can define this explicitly."""
    print("Executing (i) specific function.")
    # Add custom logic here as per your emulator's requirements.
