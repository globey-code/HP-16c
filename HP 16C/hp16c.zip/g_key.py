# g_key.py
from toggle_helpers import revert_to_normal
from g_function import g_action

# Global flag to track whether g-mode is active.
g_mode_active = False

def toggle_g_state(button_widgets):
    global g_mode_active
    # If g-mode is already active, cancel it by reverting all non-toggle buttons.
    if g_mode_active:
        for btn in button_widgets:
            # Skip the g toggle button so its blue color remains.
            if btn.get("command_name") == "blue_g_function":
                continue
            # Also skip the f toggle button.
            if btn.get("command_name") == "yellow_f_function":
                continue
            revert_to_normal(btn)
        g_mode_active = False
        return

    # Activate g-mode.
    g_mode_active = True
    for btn in button_widgets:
        # Skip both toggle buttons so their colors remain unchanged.
        if btn.get("command_name") in ("blue_g_function", "yellow_f_function"):
            continue

        revert_to_normal(btn)
        frame = btn["frame"]
        sub_label = btn.get("sub_label_widget")
        if sub_label:
            frame.config(bg="#59b7d1")
            sub_label.config(bg="#59b7d1", fg="black")
            sub_label.place(relx=0.5, rely=0.5, anchor="center")
            # Hide the other labels.
            if btn.get("main_label_widget"):
                btn.get("main_label_widget").place_forget()
            if btn.get("top_label_widget"):
                btn.get("top_label_widget").place_forget()
            # Bind click events for g-action.
            bind_widgets_to_g_action(btn, button_widgets)

def bind_widgets_to_g_action(btn, button_widgets):
    widgets = [
        btn["frame"],
        btn.get("sub_label_widget"),
        btn.get("main_label_widget"),
        btn.get("top_label_widget")
    ]
    for widget in widgets:
        if widget:
            widget.bind("<Button-1>", lambda e, b=btn: execute_g_action(b, button_widgets))

def execute_g_action(button, button_widgets):
    global g_mode_active
    g_action(button)
    # Revert all non-toggle buttons back to normal after executing the g action.
    for btn in button_widgets:
        if btn.get("command_name") in ("blue_g_function", "yellow_f_function"):
            continue
        revert_to_normal(btn)
    g_mode_active = False
